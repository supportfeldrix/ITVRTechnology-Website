# Windows Agent Installation Guide

The Windows agent collects live server metrics and reports them to the dashboard
every minute.

**Metrics collected:** OS name/version, kernel/build, CPU %, RAM, disk per drive,
uptime, process count.

**Requirements:**
- Windows Server 2016/2019/2022 or Windows 10/11
- Python 3.6+ (install for current user — no admin needed)
- Network access to your dashboard URL
- No admin / elevated rights required

> Replace `https://your-monitor-host:PORT` below with your actual dashboard URL,
> and `YOUR_TOKEN` with the token from the dashboard's Agent Setup button.

---

## Step 1 — Add the server in the dashboard

**Server Inventory → + Add Server**, fill in the details, **Save**. Then open the
server card → **Agent Setup** to get the token.

## Step 2 — Install Python (if needed)

```powershell
python --version        # check
winget install Python.Python.3   # install (current user), if missing
```

## Step 3 — Copy the agent files

Copy the `WINDOWS_AGENT` folder to the server, e.g. `C:\uptime-agent\`. You need:
- `agent_windows.py`
- `install_agent.ps1`

## Step 4 — Run the installer

```powershell
cd C:\uptime-agent
.\install_agent.ps1 -Token "YOUR_TOKEN" -Url "https://your-monitor-host:PORT"
```

It verifies Python, installs `psutil`, tests the connection, and creates a
Scheduled Task that runs every minute.

## Step 5 — Verify

```powershell
schtasks /query /tn "UptimeAgent"
Get-Content "$env:USERPROFILE\uptime-agent\agent.log" -Tail 20
```

Refresh the dashboard — the server card shows live metrics within 1-2 minutes.

---

## Manual installation (if the installer can't be used)

### Option A — Scheduled Task
```powershell
$python = (Get-Command python).Source
$script = "C:\uptime-agent\agent_windows.py"
$token  = "YOUR_TOKEN"
$url    = "https://your-monitor-host:PORT"
$log    = "C:\uptime-agent\agent.log"
schtasks /create /tn "UptimeAgent" `
  /tr "`"$python`" `"$script`" --url `"$url`" --token `"$token`" --once >> `"$log`" 2>&1" `
  /sc minute /mo 1 /f
```

### Option B — Background process
```powershell
Start-Process python -ArgumentList "C:\uptime-agent\agent_windows.py --url https://your-monitor-host:PORT --token YOUR_TOKEN --interval 60" -WindowStyle Hidden
```

### Option C — Startup shortcut
```powershell
$startup = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup"
$shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut("$startup\UptimeAgent.lnk")
$shortcut.TargetPath  = (Get-Command python).Source
$shortcut.Arguments   = "`"C:\uptime-agent\agent_windows.py`" --url `"https://your-monitor-host:PORT`" --token `"YOUR_TOKEN`" --interval 60"
$shortcut.WindowStyle = 7
$shortcut.Save()
```

## Uninstall
```powershell
.\install_agent.ps1 -Token "x" -Uninstall
# or manually:
schtasks /delete /tn "UptimeAgent" /f
Remove-Item -Recurse "$env:USERPROFILE\uptime-agent"
```

---

## Troubleshooting

| Error | Cause | Fix |
|-------|-------|-----|
| `python not found` | Python not installed | Install from python.org or winget |
| `Invalid token` | Wrong token | Regenerate via Agent Setup |
| `Connection refused` | Dashboard unreachable | Check the URL/port is accessible |
| `Access denied` on task | No Task Scheduler rights | Use Option B or C |
| Metrics show `–` | psutil missing | `pip install psutil` |

## Command reference
```
python agent_windows.py [OPTIONS]
  --url URL          Dashboard URL (required)
  --token TOKEN      Agent token (required)
  --once             Run once and exit (for Scheduled Task)
  --interval N       Loop interval seconds (default: 60)
  --verify-ssl       Verify TLS certificate (default: off)
```
