# Uptime Monitoring

A self-hosted uptime and infrastructure monitoring dashboard: HTTP/HTTPS/TCP/keyword
monitors, database monitoring (MSSQL/PostgreSQL), server & software inventory,
SSL certificate tracking, service topology, public status pages, email alerts,
role-based access control, light/dark theme, and your own branding (name + logo).

---

## 1. Requirements

- **Python 3.9+**
- Network access from the host to whatever you want to monitor
- (Optional) database drivers if you monitor databases — see step 3

## 2. Install

```bash
# From the application folder:
python -m venv venv

# Activate the virtual environment
#   Windows:  venv\Scripts\activate
#   Linux:    source venv/bin/activate

pip install -r requirements.txt
```

To monitor databases, also install the matching driver:

```bash
pip install pymssql          # for Microsoft SQL Server
pip install psycopg2-binary  # for PostgreSQL
```

## 3. Configure

```bash
# Copy the example config and edit it
cp .env.example .env     # Windows: copy .env.example .env
```

Key settings in `.env` (all optional — sensible defaults apply):

| Setting | What it does |
|---------|--------------|
| `ADMIN_USERNAME` / `ADMIN_PASSWORD` | First-run admin account. If the password is blank, a strong one is generated and printed once at startup. |
| `COOKIE_SECURE` | `true` for HTTPS (production). Set `false` only for local HTTP testing, or you won't be able to log in. |
| `CORS_ORIGINS` | Leave blank for a normal single-host install. |
| `SECRET_KEY` | Session signing key. Auto-generated and saved to `secret.key` if blank. |
| `ENCRYPTION_KEY` | Encrypts stored database passwords. Auto-generated and saved to `encryption.key` if blank. **Back this up.** |
| `LOGIN_MAX_ATTEMPTS` / `LOGIN_WINDOW_SEC` | Login rate-limit tuning. |

## 4. Run

**Development / quick start:**
```bash
python app.py
```

**Production (Linux, HTTPS via Gunicorn):**
```bash
gunicorn app:app --bind 0.0.0.0:8080 --workers 1
```
> Start with `--workers 1`. The background monitoring loops and the in-memory
> login rate limiter assume a single process. Running multiple workers needs
> shared state (a future enhancement).

On **first run** the console prints the initial admin credentials. Open the app
in a browser, log in, and **change the admin password immediately**
(Settings → User Management).

## 5. First things to do after login

1. **Change the admin password** (Settings → User Management).
2. **Set your branding** — app name, subtitle, and logo (Settings → About → Branding).
3. **Configure email alerts** (Settings → Email Notifications).
4. **Add your monitors**, servers, and databases.

---

## Branding

Make the app your own under **Settings → About → Branding**:
- App name and subtitle (shown in the sidebar, login page, and status pages)
- Sidebar/favicon logo
- Login-panel logo

The shipped default is a neutral "Uptime / Monitoring" mark; replace it with yours.

## Roles

| Role | Access |
|------|--------|
| `admin` | Everything, including users and settings |
| `viewer` | Read-only access to monitoring sections |
| `dba` | Database monitoring only |

## Security notes

- Passwords are hashed with **bcrypt**.
- Stored **database-target passwords are encrypted at rest** using `encryption.key`.
  Keep that file (or your `ENCRYPTION_KEY`) safe and backed up.
- The login endpoint is **rate-limited** per IP.
- Run behind **HTTPS** in production and keep `COOKIE_SECURE=true`.
- `secret.key`, `encryption.key`, `.env`, and `uptime.db` contain sensitive data —
  never commit them to source control (see `.gitignore`).

## Backup & restore

- **Backup:** Settings → Export / Import → Export Backup (JSON).
- The backup includes configuration. Database-target passwords are stored
  encrypted; they only decrypt on an install that has the **same** `encryption.key`.
  If you restore onto a different install, re-enter database passwords.
- Also back up the SQLite file (`uptime.db`), `secret.key`, and `encryption.key`.

## Files that hold secrets (do not share)

```
.env               your configuration
secret.key         session signing key
encryption.key     key for encrypting stored DB credentials
uptime.db          the database (users, monitors, encrypted credentials)
```
