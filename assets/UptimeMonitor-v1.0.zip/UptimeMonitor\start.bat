@echo off
chcp 65001 >nul
title Uptime Monitoring

echo.
echo  ============================================
echo   Uptime Monitoring - Starting...
echo  ============================================
echo.

cd /d "%~dp0"

IF NOT EXIST "venv\Scripts\activate.bat" (
    echo  [1/3] Creating Python virtual environment...
    python -m venv venv
    if errorlevel 1 (
        echo  ERROR: Python not found. Please install Python 3.x
        pause
        exit /b 1
    )
    echo  Done.
    echo.
)

echo  [2/3] Activating environment and checking dependencies...
call venv\Scripts\activate.bat
pip install -q -r requirements.txt --quiet
echo  Done.
echo.

echo  [3/3] Starting server...
echo.
echo  ============================================
echo   Open browser at:  http://localhost:5000
echo.
echo   On first run, the console prints the initial
echo   admin login. Save it and change it after login.
echo.
echo   Default status page:
echo     http://localhost:5000/?page=default
echo.
echo   Press Ctrl+C to stop the server
echo  ============================================
echo.

set PYTHONIOENCODING=utf-8
python app.py
