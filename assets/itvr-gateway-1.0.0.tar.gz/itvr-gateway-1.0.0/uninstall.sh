#!/usr/bin/env bash
#
# ITVR Gateway — stop and remove.
#   ./uninstall.sh            stop, keep data
#   ./uninstall.sh --purge    stop AND delete the data volume (irreversible)

set -euo pipefail

echo "==> Stopping ITVR Gateway"
podman pod rm -f itvr-gateway 2>/dev/null || true

if [[ "${1:-}" == "--purge" ]]; then
  echo "==> Deleting the data volume (routes, upstreams, users, logs)"
  podman volume rm itvr-gateway-data 2>/dev/null || true
  echo "    Data removed."
else
  echo "==> Data volume preserved. Re-run ./install.sh to start again."
fi
