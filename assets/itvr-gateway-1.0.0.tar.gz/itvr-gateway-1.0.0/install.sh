#!/usr/bin/env bash
#
# ITVR Gateway — end-user installer (offline, pre-built images).
#
# This is the installer that ships INSIDE the downloadable release bundle.
# It loads the pre-built container images and starts the pod. No building,
# no source, no internet required.
#
# Usage:
#   tar xzf itvr-gateway-<version>.tar.gz
#   cd itvr-gateway-<version>
#   ./install.sh

set -euo pipefail

# Resolve the bundle directory (where this script lives).
SOURCE="${BASH_SOURCE[0]}"
while [[ -h "${SOURCE}" ]]; do
  DIR="$(cd -P "$(dirname "${SOURCE}")" >/dev/null 2>&1 && pwd)"
  SOURCE="$(readlink "${SOURCE}")"
  [[ "${SOURCE}" != /* ]] && SOURCE="${DIR}/${SOURCE}"
done
BUNDLE_DIR="$(cd -P "$(dirname "${SOURCE}")" >/dev/null 2>&1 && pwd)"

IMAGE_TAR="${BUNDLE_DIR}/images/itvr-gateway-images.tar"
ENV_FILE="${BUNDLE_DIR}/.env"
TEMPLATE="${BUNDLE_DIR}/itvr-gateway.yaml"
RENDERED="$(mktemp -t itvr-gateway.rendered.XXXXXX.yaml)"

echo "==> ITVR Gateway installer"

# ---- Prerequisite check ----
if ! command -v podman >/dev/null 2>&1; then
  echo "ERROR: podman is not installed." >&2
  echo "       On Fedora/RHEL:  sudo dnf install -y podman" >&2
  exit 1
fi

if [[ ! -f "${IMAGE_TAR}" ]]; then
  echo "ERROR: image archive not found at ${IMAGE_TAR}" >&2
  echo "       Make sure you extracted the full release bundle." >&2
  exit 1
fi

# ---- Load overrides from .env (if present), else defaults ----
ITVR_GATEWAY_JWT_SECRET="change-me-to-a-long-random-string"
ITVR_GATEWAY_ADMIN_USERNAME="admin"
ITVR_GATEWAY_ADMIN_PASSWORD="admin123"
ITVR_GATEWAY_LOG_RETENTION_DAYS="7"
ITVR_GATEWAY_PROXY_PORT="8080"
ITVR_GATEWAY_ADMIN_PORT="9180"
ITVR_GATEWAY_DASHBOARD_PORT="8081"

if [[ -f "${ENV_FILE}" ]]; then
  echo "==> Loading settings from .env"
  set -a; source "${ENV_FILE}"; set +a
else
  echo "==> No .env found; using defaults (copy .env.example to .env to customise)"
fi

# ---- Load the pre-built images ----
echo "==> Loading container images (this can take a moment)"
podman load -i "${IMAGE_TAR}"

# ---- Enable + relabel the Podman socket (Containers tab, SELinux hosts) ----
PODMAN_SOCKET="/run/user/$(id -u)/podman/podman.sock"
if [[ ! -S "${PODMAN_SOCKET}" ]]; then
  echo "==> Enabling the rootless Podman API socket (for the Containers view)"
  systemctl --user enable --now podman.socket 2>/dev/null || \
    echo "    (could not enable automatically; Containers tab will be unavailable"
  echo "     until you run: systemctl --user enable --now podman.socket)"
fi
if command -v chcon >/dev/null 2>&1 && [[ -S "${PODMAN_SOCKET}" ]]; then
  chcon -t container_file_t "${PODMAN_SOCKET}" 2>/dev/null || true
fi

# ---- Render the manifest with settings + real socket path ----
echo "==> Preparing configuration"
sed \
  -e "s|change-me-in-production|${ITVR_GATEWAY_JWT_SECRET}|g" \
  -e "s|value: \"admin\"|value: \"${ITVR_GATEWAY_ADMIN_USERNAME}\"|" \
  -e "s|value: \"admin123\"|value: \"${ITVR_GATEWAY_ADMIN_PASSWORD}\"|" \
  -e "s|value: \"7\"|value: \"${ITVR_GATEWAY_LOG_RETENTION_DAYS}\"|" \
  -e "s|hostPort: 8080|hostPort: ${ITVR_GATEWAY_PROXY_PORT}|" \
  -e "s|hostPort: 9180|hostPort: ${ITVR_GATEWAY_ADMIN_PORT}|" \
  -e "s|hostPort: 8081|hostPort: ${ITVR_GATEWAY_DASHBOARD_PORT}|" \
  -e "s|/run/user/1000/podman/podman.sock|${PODMAN_SOCKET}|" \
  "${TEMPLATE}" > "${RENDERED}"

# ---- (Re)deploy ----
echo "==> Stopping any previous instance (ignored if none)"
podman pod rm -f itvr-gateway 2>/dev/null || true

echo "==> Starting ITVR Gateway"
podman kube play "${RENDERED}"
rm -f "${RENDERED}"

echo ""
echo "============================================================"
echo " ITVR Gateway is starting."
echo ""
echo "   Dashboard:  http://localhost:${ITVR_GATEWAY_DASHBOARD_PORT}"
echo "   Proxy:      http://localhost:${ITVR_GATEWAY_PROXY_PORT}   (your API traffic)"
echo ""
echo "   Login:      ${ITVR_GATEWAY_ADMIN_USERNAME} / (your password)"
echo ""
echo "   Status:     podman ps --pod"
echo "   Stop:       ./uninstall.sh"
echo "============================================================"
