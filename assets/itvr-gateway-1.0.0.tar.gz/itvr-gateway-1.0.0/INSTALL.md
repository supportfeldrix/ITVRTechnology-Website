# ITVR Gateway — Install Guide

A lightweight API gateway with a management dashboard, delivered as two
pre-built containers that run together with Podman.

## Requirements

- Linux with **Podman** (Fedora/RHEL recommended; Podman ships by default on Fedora)
  - Install if needed: `sudo dnf install -y podman`
- Rootless Podman (the default) — no root needed to run the gateway
- Ports **8080**, **8081**, and **9180** free on the host

## Install

```bash
tar xzf itvr-gateway-<version>.tar.gz
cd itvr-gateway-<version>

# (optional) set your admin password, ports, and secret:
cp .env.example .env
#   edit .env

./install.sh
```

When it finishes, open the dashboard:

| Service | URL |
|---------|-----|
| **Dashboard** | http://localhost:8081 |
| Proxy (your API traffic) | http://localhost:8080 |

Log in with the admin credentials from your `.env` (defaults: `admin` / `admin123`).

> **Change the defaults.** Before real use, set a strong `ITVR_GATEWAY_ADMIN_PASSWORD`
> and a long random `ITVR_GATEWAY_JWT_SECRET` in `.env`, then re-run `./install.sh`.

## What it does

- **Routes / Upstreams / Consumers** — manage gateway configuration from the UI
- **Monitoring** — live traffic, status codes, latency, per-minute trends
- **Log Viewer** — recent requests with filters and a response-time chart
- **Containers** — health of your Podman containers (CPU, memory, status)
- **Plugins** — JWT auth, rate limiting, CORS, request logging
- **Backup & Restore** — export/import your configuration
- **Settings** — users, roles, password

## Manage

```bash
podman ps --pod            # see the running pod
podman logs itvr-gateway-backend
./uninstall.sh             # stop (keeps your data)
./uninstall.sh --purge     # stop AND delete all data
```

## Data

Your configuration and logs persist in a Podman volume (`itvr-gateway-data`),
so they survive restarts and re-installs. Request-log retention defaults to 7
days (set `ITVR_GATEWAY_LOG_RETENTION_DAYS` in `.env`).

## Auto-start on boot (optional)

To have ITVR Gateway come back automatically after a reboot:

```bash
# generate a user service for the running pod
podman generate systemd --name itvr-gateway --files --new
mkdir -p ~/.config/systemd/user
mv pod-itvr-gateway.service container-*.service ~/.config/systemd/user/ 2>/dev/null || true
systemctl --user daemon-reload
systemctl --user enable pod-itvr-gateway.service
# allow user services to run without being logged in:
loginctl enable-linger "$USER"
```

## SELinux note (Fedora)

The **Containers** tab reads the host's Podman socket. On SELinux-enforcing
systems the installer relabels the socket and the backend container runs
SELinux-unconfined for that access. If your security policy forbids this, the
Containers tab will simply show as unavailable — everything else works normally.

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| `podman: command not found` | `sudo dnf install -y podman` |
| Dashboard won't load | `podman ps --pod` — is the pod running? Check `podman logs itvr-gateway-backend` |
| Login fails | Confirm the password in `.env`, then re-run `./install.sh` |
| Containers tab "unavailable" | `systemctl --user enable --now podman.socket`, then re-run `./install.sh` |
| Port already in use | Change the ports in `.env` and re-run `./install.sh` |
