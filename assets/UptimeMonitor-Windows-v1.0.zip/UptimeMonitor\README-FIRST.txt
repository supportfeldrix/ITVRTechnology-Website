Uptime Monitoring — Quick Start (Windows)
=========================================

1. Put UptimeMonitor.exe in a folder of its own (e.g. C:\UptimeMonitor).
   The app creates its database, settings and log next to the .exe, so keep
   it in a folder where it can write files.

2. Double-click UptimeMonitor.exe.
   The app starts and your browser opens automatically at
   http://localhost:5000  — and an icon appears in your system tray
   (bottom-right, near the clock).

3. On first run you'll see a "Create your admin account" screen.
   Choose a username and password — that's your login from then on.

4. You're in. Set your own name and logo under Settings -> About -> Branding,
   then add your first monitors, servers and status pages.

STAYING ON / THE SYSTEM TRAY
----------------------------
The app keeps running in the background even if you close the browser tab.
Right-click the tray icon for:
   - Open Dashboard   reopen the dashboard in your browser any time
   - Start on login   tick this so the app starts automatically after a reboot
   - Open logs        view the log file (uptime-monitor.log)
   - Quit             stop the app completely

So: closing the browser tab does NOT stop monitoring. To actually stop the
app, use Quit from the tray menu.

PLANS
-----
Free: up to 4 monitors. PRO: unlimited.
To upgrade, buy a PRO licence key and enter it under
Settings -> About -> Licence & Plan -> Activate PRO.
Contact info@itvrtechnology.co.za for a key.

YOUR DATA (back these up)
-------------------------
   uptime.db          your monitors, servers, users and settings
   secret.key         session signing key
   encryption.key     decrypts stored database-monitor passwords
   uptime-monitor.log application log

Licensing & support:  info@itvrtechnology.co.za  ·  itvrtechnology.co.za

This software is licensed, not sold. See LICENSE.txt. Reselling or
redistributing it without written permission from ITVR Technology is
not permitted.
